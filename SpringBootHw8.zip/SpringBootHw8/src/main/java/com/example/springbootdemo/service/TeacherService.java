package com.example.springbootdemo.service;

import com.example.springbootdemo.entity.Teacher;
import com.example.springbootdemo.repostitory.JPATeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeacherService {

    @Autowired
    private JPATeacherRepository jpaTeacherRepository;


    //list all teachers
    public List<Teacher> listAllTeacher() {
        return jpaTeacherRepository.findAll();
    }


    //get a teacher by id
    public Teacher getTeacherById(String id) {
        Optional<Teacher> load = jpaTeacherRepository.findById(id);
        if (load.isPresent()) {
            return load.get();
        }
        return null;
    }

    //create a teacher
    public void createTeacher(Teacher teacher) {
        jpaTeacherRepository.save(teacher);
    }

    //delete a teacher
    public void removeTeacher(String id) {
        if (id == null) {
            System.out.println("Teacher id is null !");
        }else {
            jpaTeacherRepository.deleteById(id);
        }
    }

//    public void addStudent(Teacher teacher, Student student) {
//        jpaTeacherRepository.addStudent(teacher,student);
//    }

//    public List<Teacher> listAllTeacher(int page, int sizePerPage) {
//        Pageable pageable = PageRequest.of(page, sizePerPage, Sort.by("id"));
//        return jpaTeacherRepository.listAllTeacher(pageable);
//    }
}
