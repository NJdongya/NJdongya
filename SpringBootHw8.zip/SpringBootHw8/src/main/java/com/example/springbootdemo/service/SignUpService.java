package com.example.springbootdemo.service;

import com.example.springbootdemo.entity.Student;
import com.example.springbootdemo.entity.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class SignUpService {
    @Autowired
    private StudentService studentService;
    @Autowired
    private TeacherService teacherService;

    public void signUpTeacher(String studentId, String teacherId) {
        Student student = studentService.getStudentById(studentId);
        Teacher teacher = teacherService.getTeacherById(teacherId);

        if (student != null && teacher != null) {
            student.getTeachers().add(teacher);
            studentService.createStudent(student);
//            teacherService.addStudent(teacher, student);
//            teacherService.createTeacher(teacher);
        }
    }

    public void deleteTeacher(String studentId, String teacherId) {
        Student student = studentService.getStudentById(studentId);
        Teacher teacher = teacherService.getTeacherById(teacherId);

        if (student != null && teacher != null) {
            student.getTeachers().remove(teacher);
            studentService.createStudent(student);
//            teacher.students.remove(student);
//            teacherService.createTeacher(teacher);
        }
    }


//    public void upDateTeacher(String studentId, String new_teacherId){
//
//        Student student = studentService.getStudentById(studentId);
//        Teacher pre_teacher = teacherService.getTeacherById(student.getTeacherId());
//
//        deleteTeacher(studentId, pre_teacher.getId());
//        signUpTeacher(studentId, new_teacherId);
//
//    }


}