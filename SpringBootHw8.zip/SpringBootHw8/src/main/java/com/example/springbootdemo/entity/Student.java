package com.example.springbootdemo.entity;

import jakarta.persistence.*;

import java.util.Set;


@Entity
@Table(name = "Student")
public class Student {

    @Id
    @Column(name = "student_id")
    private String id;
    @Column(name = "name")
    private String name;
    @Column(name = "address")
    private String address;


    @ManyToMany(cascade = {
            CascadeType.DETACH,
            CascadeType.MERGE,
            CascadeType.REFRESH,
            CascadeType.PERSIST
    })
    @JoinTable(name = "Student_Teacher", joinColumns = {@JoinColumn(name = "student_id", referencedColumnName = "student_id") },
    inverseJoinColumns = {@JoinColumn(name = "teacher_id", referencedColumnName = "teacher_id")})
    private Set<Teacher> teachers;


    public Set<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(Set<Teacher> teachers) {
        this.teachers = teachers;
    }

    public Student() {}

    public Student (String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", address='" + address +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

