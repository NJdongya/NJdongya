package com.example.springbootdemo.controller;
import com.example.springbootdemo.service.SignUpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class SignUpController {
    @Autowired
    private SignUpService signUpService;


    @PostMapping(value = "/signup")
    public void signUpTeacher(@RequestParam(value = "studentId") String studentId,
                              @RequestParam(value = "teacherId") String teacherId) {

        signUpService.signUpTeacher(studentId, teacherId);
    }

    @DeleteMapping(value = "/delete")
    public void deleteTeacher(@RequestParam(value = "studentId") String studentId,
                              @RequestParam(value = "teacherId") String teacherId){

        signUpService.deleteTeacher(studentId,teacherId);
    }

    //    @PutMapping(value = "/update")
//    public void upDateTeacher(@RequestParam(value = "studentId") String studentId,
//                              @RequestParam(value = "new_teacherId") String new_teacherId){
//
//        signUpService.upDateTeacher(studentId, new_teacherId);
//    }
}
