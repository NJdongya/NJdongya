package com.example.springbootdemo.repostitory;


import com.example.springbootdemo.entity.Student;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JPAStudentRepository extends JpaRepository<Student, String> {

    //List<Student> findStudentByName(String name);
    List<Student> findStudentByName(String name, Pageable pageable);

    //List<Student> listAllStudents(Pageable pageable);

}
