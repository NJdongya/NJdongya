package com.example.springbootdemo.controller;

import com.example.springbootdemo.entity.Student;
import com.example.springbootdemo.entity.Teacher;
import com.example.springbootdemo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TeacherController {
    @Autowired
    private TeacherService service = new TeacherService();

    //create a teacher
    @PostMapping(value = "/create/teacher")
    public void createTeacher(@RequestBody Teacher teacher) {
        service.createTeacher(teacher);
    }

    //list all teachers
    @GetMapping(value = "/list/teachers")
    public List<Teacher> listAllTeacher() {
        return service.listAllTeacher();
    }

    //get a teacher by id
    @GetMapping(value = "/get/teacher")
    @ResponseBody
    public Teacher getTeacherById(@RequestParam(value = "id") String id) {
        return service.getTeacherById(id);
    }

    //delete a teacher
    @DeleteMapping(value = "/delete/teacher")
    public void removeTeacher(@RequestParam(value = "id") String id) {
        service.removeTeacher(id);
    }

    //    @GetMapping(value = "/list/teachers")
//    public List<Teacher> listAllTeacher(@RequestParam(value = "page") int page,
//                                            @RequestParam(value = "size_per_page") int sizePerPage){
//        return service.listAllTeacher(page,sizePerPage);
//    }
    //    @PostMapping(value = "/create/teacher")
//    public void createTeacher(@RequestParam(value = "id") String id, @RequestParam(value = "name") String name,
//                              @RequestParam(value = "address") String address) {
//        System.out.println("teacher");
//        Teacher teacher = new Teacher(id, name, address);
//        service.createTeacher(teacher);
//    }
}
