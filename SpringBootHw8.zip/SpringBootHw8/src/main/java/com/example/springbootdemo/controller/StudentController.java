package com.example.springbootdemo.controller;

import com.example.springbootdemo.entity.Student;
import com.example.springbootdemo.entity.Teacher;
import com.example.springbootdemo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StudentController {

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String start() {
        return "hello world!";
    }

    @Autowired
    private StudentService service = new StudentService();

    //list all students
    @GetMapping(value = "/list/students")
    public List<Student> listAllStudent() {
        return service.listAllStudent();
    }

   //get students by name
    @GetMapping(value = "/list/students/name")
    public List<Student> listStudentsByName(@RequestParam(value = "name") String name,
                                            @RequestParam(value = "page") int page,
                                            @RequestParam(value = "size_per_page") int sizePerPage){
        return service.listStudentsByName(name,page,sizePerPage);
    }

    //get a student by id
    @GetMapping(value = "/get/student")
    @ResponseBody
    public Student getStudentById(@RequestParam(value = "id") String id) {
        System.out.println(service.getStudentById(id));
        return service.getStudentById(id);
    }

    //create a student
    @PostMapping(value = "/create/student")
    public void createStudent(@RequestParam(value = "id") String id, @RequestParam(value = "name") String name,
                              @RequestParam(value = "address") String address) {
        Student student = new Student(id, name);
        student.setAddress(address);
        service.createStudent(student);
    }

    //update a student's address
    @PutMapping(value = "/update/student")
    public void updateStudent(@RequestParam(value = "id") String id,@RequestParam(value = "address") String address) {
        Student student = service.getStudentById(id);
        student.setAddress(address);
        service.createStudent(student);
    }

    //delete a student
    @DeleteMapping(value = "/delete/student")
    public void removeStudent(@RequestParam(value = "id") String id) {
        service.removeStudent(id);
    }

//    @GetMapping(value = "/list/students")
//    public List<Student> listAllStudent(@RequestParam(value = "page") int page,
//                                        @RequestParam(value = "size_per_page") int sizePerPage){
//        return service.listAllStudent(page,sizePerPage);
//    }


}
