package com.example.springbootdemo.repostitory;

import com.example.springbootdemo.entity.Teacher;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface JPATeacherRepository extends JpaRepository<Teacher, String> {

    //List<Teacher> listAllTeacher(Pageable pageable);

}
