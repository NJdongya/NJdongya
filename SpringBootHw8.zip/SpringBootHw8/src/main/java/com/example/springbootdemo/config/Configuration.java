package com.example.springbootdemo.config;

@org.springframework.context.annotation.Configuration
public class Configuration {

//    @Bean
//    public JPARepository buildJPARepository(){
//        return new JPARepository();
//    }


}
