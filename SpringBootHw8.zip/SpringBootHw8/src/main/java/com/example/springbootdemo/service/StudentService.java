package com.example.springbootdemo.service;

import com.example.springbootdemo.entity.Student;
import com.example.springbootdemo.repostitory.JPAStudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private JPAStudentRepository jpaStudentRepository ;


    //list all students
    public List<Student> listAllStudent() {
        return jpaStudentRepository.findAll();
    }

    //create a student
    public void createStudent(Student student) {
        jpaStudentRepository.save(student);
    }

    //delete a student
    public void removeStudent(String id) {
        if (id == null) {
            System.out.println("Student id is null !");
        }else {
            jpaStudentRepository.deleteById(id);
        }

    }

    //get a student by id
    public Student getStudentById(String id) {
        Optional<Student> load = jpaStudentRepository.findById(id);
        if (load.isPresent()) {
            return load.get();
        }
        return null;
    }

    //get students by name
    public List<Student> listStudentsByName(String name, int page, int sizePerPage) {
        Pageable pageable = PageRequest.of(page, sizePerPage, Sort.by("id"));
        return jpaStudentRepository.findStudentByName(name, pageable);
    }
}
